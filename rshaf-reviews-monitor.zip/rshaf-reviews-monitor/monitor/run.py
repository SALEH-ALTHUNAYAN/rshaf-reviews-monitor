"""Entry point.

python -m monitor.run --mode collect   # every 2h: fetch → analyze → alert
python -m monitor.run --mode daily     # collect + daily digest
python -m monitor.run --mode weekly    # collect + weekly report
python -m monitor.run --mode analyze   # (re)analyze + alert only, no fetch
"""
import argparse
from datetime import timedelta

from .analyze import analyze_pending
from .common import (iso, load_config, load_state, load_store, log, now_utc,
                     owner_chats, parse_iso, save_state, save_store,
                     telegram_send)
from .notify import mark_existing_as_alerted, send_alerts, send_daily, send_weekly
from .sources import get_source

KEEP_FIELDS_ON_UPDATE = ("analysis", "alerted", "collected_at")


def collect(store, state, cfg):
    started = now_utc()
    last = parse_iso(state.get("last_success_utc"))
    first_run = last is None
    if first_run:
        since = started - timedelta(days=cfg.get("first_run_backfill_days", 90))
    else:
        since = last - timedelta(hours=cfg["apify"].get("overlap_hours", 6))

    fetched = get_source(cfg).fetch(since)

    by_id = {r["id"]: r for r in store["reviews"]}
    new = 0
    for r in fetched:
        old = by_id.get(r["id"])
        if old is None:
            r["collected_at"] = iso(started)
            store["reviews"].append(r)
            by_id[r["id"]] = r
            new += 1
        else:
            # Review edited by customer or owner replied → refresh content.
            changed = (old.get("text") != r["text"] or old.get("stars") != r["stars"])
            for k, v in r.items():
                if k not in KEEP_FIELDS_ON_UPDATE:
                    old[k] = v
            if changed:
                old["analysis"] = None
                old["alerted"] = None
                old["edited"] = True

    if first_run:
        mark_existing_as_alerted(store)
    state["last_success_utc"] = iso(started)
    state["last_source"] = cfg.get("source")
    log(f"Collected {len(fetched)} (new {new}, backfill={first_run})")
    return new, first_run


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default="collect",
                    choices=["collect", "daily", "weekly", "analyze"])
    args = ap.parse_args()

    cfg = load_config()
    store, state = load_store(), load_state()

    try:
        if args.mode != "analyze":
            new, first_run = collect(store, state, cfg)
            save_store(store)
            save_state(state)
        analyze_pending(store, cfg)
        save_store(store)
        send_alerts(store, cfg)
        save_store(store)
    except Exception as e:
        # Tell the owner once if something breaks, then fail the job.
        fails = state.get("consecutive_failures", 0) + 1
        state["consecutive_failures"] = fails
        save_state(state)
        if fails in (2, 10):
            telegram_send(owner_chats(),
                          f"⚠️ نظام متابعة التعليقات فشل {fails} مرات متتالية:\n<code>{str(e)[:300]}</code>")
        raise
    state["consecutive_failures"] = 0
    save_state(state)

    if args.mode == "daily":
        send_daily(store, cfg)
    elif args.mode == "weekly":
        send_weekly(store, cfg)


if __name__ == "__main__":
    main()
