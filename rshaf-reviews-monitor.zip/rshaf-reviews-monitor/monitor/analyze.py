"""Classify reviews with Claude (topics, sentiment, severity, staff mentions)."""
import json
import re

import requests

from .common import env, log

TOPICS = {
    "taste": "الطعم والجودة",
    "speed": "السرعة والانتظار",
    "staff": "تعامل الموظفين",
    "accuracy": "دقة الطلب",
    "price": "السعر والقيمة",
    "hygiene": "النظافة وسلامة الغذاء",
    "facility": "المكان والدرايف ثرو والمواقف",
    "availability": "توفر المنتجات",
    "hours": "أوقات العمل والإغلاق",
    "payment": "الدفع والتطبيقات",
    "other": "أخرى",
}

SYSTEM = f"""أنت محلل تجربة عملاء لمقاهي ومطاعم في منطقة القصيم بالسعودية:
- "رشف": مقهى درايف ثرو (قهوة مختصة، مشروبات باردة، حلويات ودونات من معمل الشركة).
- "ارميما": مطعم برجر.

لكل تعليق أعد كائن JSON بالحقول التالية بالضبط:
- "id": نفس المعرّف كما هو
- "sentiment": "positive" أو "neutral" أو "negative"
- "topics": قائمة من هذه المفاتيح فقط تذكر المواضيع المطروحة فعلاً: {list(TOPICS)}
- "negative_topics": المواضيع التي اشتكى منها العميل فقط (قائمة فرعية من topics)
- "severity": "none" للإيجابي، أو "low" / "medium" / "high" / "critical"
   (critical = سلامة غذاء، جسم غريب، تسمم، إساءة أو صراخ من موظف، مخالفة نظامية)
- "summary": ملخص عربي في سطر واحد قصير (أقل من 15 كلمة)
- "staff_mentions": قائمة بأسماء الموظفين المذكورين: [{{"name": "الاسم كما كُتب", "sentiment": "positive|negative"}}]
- "products": أسماء المنتجات المذكورة (قائمة نصوص قصيرة)
- "action": إجراء عملي مقترح للمشرف بجملة واحدة إذا كان فيه شكوى، وإلا ""

قواعد: التعليق بدون نص يُحكم عليه من النجوم فقط. لا تخترع معلومات غير موجودة.
أعد مصفوفة JSON فقط، بدون أي نص قبلها أو بعدها."""


def _fallback(r):
    s = r.get("stars") or 3
    sentiment = "positive" if s >= 4 else ("neutral" if s == 3 else "negative")
    return {
        "sentiment": sentiment, "topics": [], "negative_topics": [],
        "severity": "none" if s >= 4 else ("low" if s == 3 else "medium"),
        "summary": "", "staff_mentions": [], "products": [], "action": "",
        "model": "stars-only",
    }


def _extract_json(text):
    m = re.search(r"\[.*\]", text, re.S)
    return json.loads(m.group(0) if m else text)


def _call_claude(batch, model):
    payload = [
        {"id": r["id"], "brand": r["brand"], "branch": r["branch_name"],
         "stars": r["stars"], "text": r["text"] or r.get("text_translated") or ""}
        for r in batch
    ]
    resp = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": env("ANTHROPIC_API_KEY", required=True),
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        json={
            "model": model,
            "max_tokens": 4000,
            "system": SYSTEM,
            "messages": [{"role": "user",
                          "content": json.dumps(payload, ensure_ascii=False)}],
        },
        timeout=120,
    )
    if not resp.ok:
        raise RuntimeError(f"Claude {resp.status_code}: {resp.text[:300]}")
    text = "".join(b.get("text", "") for b in resp.json()["content"])
    return {str(x["id"]): x for x in _extract_json(text)}


def analyze_pending(store, cfg):
    use_claude = bool(env("ANTHROPIC_API_KEY"))

    def needs(r):
        a = r.get("analysis")
        if not a:
            return True
        # Retry reviews that only got the stars fallback (e.g. API was down).
        return use_claude and a.get("model") == "stars-only" and a.get("attempts", 0) < 3

    pending = [r for r in store["reviews"] if needs(r)]
    if not pending:
        return 0
    model = cfg["claude"]["model"]
    size = cfg["claude"].get("batch_size", 15)
    done = 0
    for i in range(0, len(pending), size):
        batch = pending[i:i + size]
        results = {}
        if use_claude:
            try:
                results = _call_claude(batch, model)
            except Exception as e:  # keep going; fall back to stars
                log(f"Claude batch failed, using stars fallback: {e}")
        for r in batch:
            a = results.get(r["id"])
            if a:
                a.pop("id", None)
                a["topics"] = [t for t in a.get("topics", []) if t in TOPICS]
                a["negative_topics"] = [t for t in a.get("negative_topics", []) if t in TOPICS]
                a["model"] = model
                r["analysis"] = a
            else:
                prev = (r.get("analysis") or {}).get("attempts", 0)
                r["analysis"] = _fallback(r)
                r["analysis"]["attempts"] = prev + (1 if use_claude else 0)
            done += 1
    log(f"Analyzed {done} reviews (claude={'on' if use_claude else 'off'})")
    return done
