"""Shared helpers: config, data store, time, Telegram."""
import html
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
REVIEWS_PATH = DATA_DIR / "reviews.json"
STATE_PATH = DATA_DIR / "state.json"


def log(*args):
    print("[monitor]", *args, file=sys.stderr, flush=True)


# ---------- config ----------
def load_config():
    with open(ROOT / "config.json", encoding="utf-8") as f:
        cfg = json.load(f)
    cfg["_by_place"] = {b["place_id"]: b for b in cfg["branches"]}
    cfg["_by_id"] = {b["id"]: b for b in cfg["branches"]}
    return cfg


def env(name, required=False, default=None):
    val = os.environ.get(name, "").strip()
    if not val:
        if required:
            raise SystemExit(f"Missing required secret/env: {name}")
        return default
    return val


# ---------- time ----------
def now_utc():
    return datetime.now(timezone.utc)


def iso(dt):
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_iso(s):
    if not s:
        return None
    s = s.replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def local_str(dt, cfg, fmt="%Y-%m-%d %H:%M"):
    off = timedelta(hours=cfg.get("timezone_offset_hours", 3))
    return (dt.astimezone(timezone.utc) + off).strftime(fmt)


# ---------- store ----------
def _read_json(path, default):
    if path.exists():
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    return default


def _write_json(path, obj):
    DATA_DIR.mkdir(exist_ok=True)
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    tmp.replace(path)


def load_store():
    return _read_json(REVIEWS_PATH, {"updated_at": None, "reviews": []})


def save_store(store):
    store["updated_at"] = iso(now_utc())
    store["reviews"].sort(key=lambda r: r.get("published_at") or "", reverse=True)
    _write_json(REVIEWS_PATH, store)


def load_state():
    return _read_json(STATE_PATH, {})


def save_state(state):
    _write_json(STATE_PATH, state)


# ---------- telegram ----------
def esc(s):
    return html.escape(str(s or ""), quote=False)


def _chunks(text, limit=3900):
    parts, cur = [], ""
    for line in text.split("\n"):
        if len(cur) + len(line) + 1 > limit:
            parts.append(cur)
            cur = ""
        cur += line + "\n"
    if cur.strip():
        parts.append(cur)
    return parts


def telegram_send(chat_ids, text):
    """Send an HTML message to each chat id. DRY_RUN=1 prints instead."""
    chat_ids = [str(c) for c in chat_ids if str(c).strip()]
    if not chat_ids:
        return
    if os.environ.get("DRY_RUN") == "1" or not env("TELEGRAM_BOT_TOKEN"):
        for c in chat_ids:
            print(f"\n----- Telegram → {c} -----\n{text}")
        return
    token = env("TELEGRAM_BOT_TOKEN")
    for chat in chat_ids:
        for part in _chunks(text):
            r = requests.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={
                    "chat_id": chat,
                    "text": part,
                    "parse_mode": "HTML",
                    "disable_web_page_preview": True,
                },
                timeout=30,
            )
            if not r.ok:
                log(f"Telegram error for {chat}: {r.status_code} {r.text[:200]}")


def owner_chats():
    raw = env("TELEGRAM_OWNER_CHAT_ID", default="")
    return [c.strip() for c in raw.split(",") if c.strip()]
