"""Telegram notifications: instant alerts, daily digest, weekly report."""
import json
from collections import Counter, defaultdict
from datetime import timedelta

import requests

from .analyze import TOPICS
from .common import (env, esc, local_str, log, now_utc, owner_chats,
                     parse_iso, telegram_send)

STAR = "⭐"
SEV_AR = {"critical": "🚨 حرج", "high": "🔴 عالي", "medium": "🟠 متوسط",
          "low": "🟡 منخفض", "none": "—"}


def _a(r):
    return r.get("analysis") or {}


def _is_alert(r, cfg):
    rules = cfg["alerts"]
    s = r.get("stars") or 0
    return (s and s <= rules["max_stars"]) or _a(r).get("severity") in rules["also_alert_severity"]


def _review_block(r, cfg, with_action=True):
    a = _a(r)
    lines = [
        f"<b>{esc(r['brand'])} | {esc(r['branch_name'])}</b>",
        f"{STAR * (r.get('stars') or 0)}  ({r.get('stars')}/5)   الخطورة: {SEV_AR.get(a.get('severity'), '—')}",
    ]
    pub = parse_iso(r.get("published_at"))
    if pub:
        lines.append(f"🕒 {local_str(pub, cfg)}")
    text = r.get("text") or r.get("text_translated")
    lines.append(f"💬 {esc(text[:700]) if text else '<i>بدون نص — تقييم بالنجوم فقط</i>'}")
    if a.get("summary"):
        lines.append(f"📝 {esc(a['summary'])}")
    if a.get("negative_topics"):
        lines.append("🏷 " + "، ".join(TOPICS[t] for t in a["negative_topics"]))
    if with_action and a.get("action"):
        lines.append(f"✅ المقترح: {esc(a['action'])}")
    if r.get("url"):
        lines.append(f'<a href="{esc(r["url"])}">فتح التعليق في قوقل</a>')
    return "\n".join(lines)


# ---------- instant ----------
def send_alerts(store, cfg):
    sent = 0
    for r in store["reviews"]:
        if r.get("alerted") or not r.get("analysis"):
            continue
        if not _is_alert(r, cfg):
            r["alerted"] = "skip"
            continue
        branch = cfg["_by_id"].get(r["branch_id"], {})
        msg = "🔔 <b>تعليق يحتاج انتباه</b>\n\n" + _review_block(r, cfg)
        telegram_send(owner_chats() + branch.get("supervisor_chat_ids", []), msg)
        r["alerted"] = True
        sent += 1
    log(f"Alerts sent: {sent}")
    return sent


def mark_existing_as_alerted(store):
    """On the very first backfill we don't want 90 days of alerts."""
    for r in store["reviews"]:
        r.setdefault("alerted", "backfill")


# ---------- stats ----------
def _window(store, days):
    since = now_utc() - timedelta(days=days)
    return [r for r in store["reviews"]
            if (parse_iso(r.get("published_at")) or since) >= since]


def _stats(reviews):
    stars = [r["stars"] for r in reviews if r.get("stars")]
    avg = sum(stars) / len(stars) if stars else 0
    neg = [r for r in reviews if _a(r).get("sentiment") == "negative"]
    topics = Counter(t for r in neg for t in _a(r).get("negative_topics", []))
    staff_pos, staff_neg = Counter(), Counter()
    for r in reviews:
        for m in _a(r).get("staff_mentions", []):
            name = (m.get("name") or "").strip()
            if name:
                (staff_pos if m.get("sentiment") == "positive" else staff_neg)[(name, r["branch_name"])] += 1
    by_branch = defaultdict(list)
    for r in reviews:
        by_branch[(r["brand"], r["branch_name"])].append(r)
    return {"count": len(reviews), "avg": avg, "neg": neg, "topics": topics,
            "staff_pos": staff_pos, "staff_neg": staff_neg, "by_branch": by_branch}


def _branch_lines(by_branch):
    rows = []
    for (brand, name), rs in by_branch.items():
        st = [r["stars"] for r in rs if r.get("stars")]
        avg = sum(st) / len(st) if st else 0
        neg = sum(1 for r in rs if _a(r).get("sentiment") == "negative")
        rows.append((avg, f"• {esc(brand)} {esc(name)}: {avg:.1f}{STAR} ({len(rs)} تعليق، {neg} سلبي)"))
    return [line for _, line in sorted(rows)]


# ---------- daily ----------
def send_daily(store, cfg):
    day = _window(store, 1)
    s = _stats(day)
    lines = [f"📊 <b>ملخص تعليقات قوقل — {local_str(now_utc(), cfg, '%Y-%m-%d')}</b>", ""]
    if not day:
        lines.append("ما وصل تعليقات جديدة خلال آخر 24 ساعة.")
    else:
        lines += [f"عدد التعليقات: <b>{s['count']}</b>   المتوسط: <b>{s['avg']:.2f}</b>{STAR}",
                  f"السلبية: <b>{len(s['neg'])}</b>", "", "<b>حسب الفرع</b>"]
        lines += _branch_lines(s["by_branch"])
        if s["topics"]:
            lines += ["", "<b>أبرز الشكاوى</b>"]
            lines += [f"• {TOPICS[t]}: {n}" for t, n in s["topics"].most_common(4)]
        if s["staff_pos"]:
            lines += ["", "<b>موظفين انشكروا بالاسم 👏</b>"]
            lines += [f"• {esc(n)} ({esc(b)}) ×{c}" for (n, b), c in s["staff_pos"].most_common(5)]
    lines += ["", f'<a href="{cfg["dashboard_url"]}">فتح لوحة المتابعة</a>']
    telegram_send(owner_chats(), "\n".join(lines))


# ---------- weekly ----------
def _claude_report(cfg, payload):
    key = env("ANTHROPIC_API_KEY")
    if not key:
        return None
    prompt = (
        "أنت مستشار تشغيل لمقهى درايف ثرو (رشف) ومطعم برجر (ارميما) في القصيم. "
        "هذه بيانات تعليقات قوقل للأسبوع الماضي مقارنة بالأسبوع الذي قبله. "
        "اكتب تقرير أسبوعي مختصر لصاحب الشركة باللهجة السعودية المهنية، بنص عادي يصلح لتيليجرام "
        "(بدون Markdown، استخدم • للنقاط وأسطر فارغة بين الأقسام)، لا يتجاوز 300 كلمة، بالأقسام:\n"
        "1) الخلاصة في سطرين\n2) أكثر 3 مشاكل متكررة مع الفروع المعنية\n"
        "3) فرع يحتاج تدخل عاجل ولماذا\n4) نقاط قوة وموظفين يستحقون التقدير\n"
        "5) 3 إجراءات محددة لهذا الأسبوع.\n"
        "اعتمد على الأرقام فقط ولا تخترع شيئاً.\n\nالبيانات:\n"
        + json.dumps(payload, ensure_ascii=False)
    )
    r = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={"x-api-key": key, "anthropic-version": "2023-06-01",
                 "content-type": "application/json"},
        json={"model": cfg["claude"].get("report_model", cfg["claude"]["model"]),
              "max_tokens": 1500,
              "messages": [{"role": "user", "content": prompt}]},
        timeout=120,
    )
    if not r.ok:
        log(f"Weekly report Claude error: {r.status_code} {r.text[:200]}")
        return None
    return "".join(b.get("text", "") for b in r.json()["content"]).strip()


def send_weekly(store, cfg):
    week = _window(store, 7)
    prev = [r for r in _window(store, 14) if r not in week]
    s, p = _stats(week), _stats(prev)

    def branch_summary(stats):
        out = {}
        for (brand, name), rs in stats["by_branch"].items():
            st = [r["stars"] for r in rs if r.get("stars")]
            out[f"{brand} - {name}"] = {
                "count": len(rs),
                "avg": round(sum(st) / len(st), 2) if st else None,
                "negative": sum(1 for r in rs if _a(r).get("sentiment") == "negative"),
                "complaints": dict(Counter(t for r in rs for t in _a(r).get("negative_topics", []))),
            }
        return out

    payload = {
        "this_week": {"count": s["count"], "avg": round(s["avg"], 2),
                      "negative": len(s["neg"]),
                      "complaints": {TOPICS[k]: v for k, v in s["topics"].items()},
                      "branches": branch_summary(s),
                      "staff_praised": [f"{n} ({b}) x{c}" for (n, b), c in s["staff_pos"].most_common(8)],
                      "staff_complained": [f"{n} ({b}) x{c}" for (n, b), c in s["staff_neg"].most_common(8)],
                      "negative_samples": [
                          f"[{r['brand']} {r['branch_name']} {r['stars']}★] {_a(r).get('summary') or (r.get('text') or '')[:150]}"
                          for r in s["neg"][:40]]},
        "last_week": {"count": p["count"], "avg": round(p["avg"], 2), "negative": len(p["neg"])},
    }
    body = _claude_report(cfg, payload)
    head = f"🗓 <b>التقرير الأسبوعي لتعليقات قوقل</b>\nالأسبوع: {s['count']} تعليق، متوسط {s['avg']:.2f}{STAR} (الأسبوع السابق {p['avg']:.2f}{STAR})\n"
    if body:
        msg = head + "\n" + esc(body)
    else:  # no API key: numbers only
        msg = head + "\n" + "\n".join(_branch_lines(s["by_branch"]))
    msg += f'\n\n<a href="{cfg["dashboard_url"]}">فتح لوحة المتابعة</a>'
    telegram_send(owner_chats(), msg)
