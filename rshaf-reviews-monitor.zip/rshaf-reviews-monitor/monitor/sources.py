"""Review sources. Each returns a list of normalized review dicts.

- ApifySource: works today (Google Maps scraper on Apify).
- GBPSource:   official Google Business Profile API. Switch config "source"
               to "gbp" once Google approves your API access.
"""
import requests

from .common import env, iso, log, parse_iso

STAR_WORDS = {"ONE": 1, "TWO": 2, "THREE": 3, "FOUR": 4, "FIVE": 5}


def _normalize(branch, *, rid, stars, text, published, url=None,
               reply=None, translated=None, source):
    return {
        "id": str(rid),
        "source": source,
        "branch_id": branch["id"],
        "brand": branch["brand"],
        "branch_name": branch["name"],
        "city": branch.get("city"),
        "stars": int(stars) if stars else None,
        "text": (text or "").strip(),
        "text_translated": (translated or "").strip() or None,
        "published_at": published,
        "url": url,
        "owner_reply": (reply or "").strip() or None,
    }


class ApifySource:
    name = "apify"

    def __init__(self, cfg):
        self.cfg = cfg
        self.token = env("APIFY_TOKEN", required=True)

    def fetch(self, since):
        a = self.cfg["apify"]
        body = {
            "placeIds": [b["place_id"] for b in self.cfg["branches"]],
            "maxReviews": a.get("max_reviews_per_run", 300),
            "reviewsSort": "newest",
            # Absolute dates are interpreted as UTC by the actor.
            "reviewsStartDate": iso(since).rstrip("Z"),
            "language": a.get("language", "ar"),
            "reviewsOrigin": "google",
            # Keep reviewer names out of the (public) dashboard data.
            "personalData": False,
        }
        url = (f"https://api.apify.com/v2/acts/{a['actor']}"
               f"/run-sync-get-dataset-items?timeout=290&format=json")
        log(f"Apify: {len(body['placeIds'])} places since {body['reviewsStartDate']}")
        r = requests.post(url, json=body, timeout=320,
                          headers={"Authorization": f"Bearer {self.token}"})
        if not r.ok:
            raise RuntimeError(f"Apify {r.status_code}: {r.text[:300]}")
        items = r.json()
        out = []
        for it in items:
            branch = self.cfg["_by_place"].get(it.get("placeId"))
            rid = it.get("reviewId")
            if not branch or not rid:
                continue
            out.append(_normalize(
                branch, source=self.name, rid=rid,
                stars=it.get("stars") or it.get("rating"),
                text=it.get("text"),
                translated=it.get("textTranslated"),
                published=it.get("publishedAtDate"),
                url=it.get("reviewUrl") or it.get("url"),
                reply=it.get("responseFromOwnerText"),
            ))
        log(f"Apify returned {len(items)} items, {len(out)} matched branches")
        return out


class GBPSource:
    """Official Business Profile API (needs approved Basic API Access)."""
    name = "gbp"

    def __init__(self, cfg):
        self.cfg = cfg
        tok = requests.post("https://oauth2.googleapis.com/token", data={
            "client_id": env("GBP_CLIENT_ID", required=True),
            "client_secret": env("GBP_CLIENT_SECRET", required=True),
            "refresh_token": env("GBP_REFRESH_TOKEN", required=True),
            "grant_type": "refresh_token",
        }, timeout=30)
        tok.raise_for_status()
        self.h = {"Authorization": f"Bearer {tok.json()['access_token']}"}

    def _get(self, url, params=None):
        r = requests.get(url, headers=self.h, params=params, timeout=60)
        if not r.ok:
            raise RuntimeError(f"GBP {r.status_code}: {r.text[:300]}")
        return r.json()

    @staticmethod
    def _auto_branch(loc):
        """A location in your account that isn't in config.json yet."""
        title = loc.get("title", "")
        brand = "ارميما" if ("ميما" in title or "mima" in title.lower()) else (
            "رشف" if ("رشف" in title or "rshaf" in title.lower()) else title)
        addr = loc.get("storefrontAddress") or {}
        city = addr.get("locality") or ""
        line = (addr.get("addressLines") or [""])[0]
        return {"id": "gbp-" + loc["name"].split("/")[-1], "brand": brand,
                "name": " - ".join(x for x in (city, line) if x) or title,
                "city": city, "supervisor_chat_ids": []}

    def _locations(self):
        """Every location in your Business Profile account → branch.
        Configured branches are matched by placeId; new ones are picked up automatically."""
        found = {}
        accts = self._get("https://mybusinessaccountmanagement.googleapis.com/v1/accounts")
        for acct in accts.get("accounts", []):
            token = None
            while True:
                data = self._get(
                    f"https://mybusinessbusinessinformation.googleapis.com/v1/{acct['name']}/locations",
                    {"readMask": "name,title,metadata,storefrontAddress", "pageSize": 100, "pageToken": token})
                for loc in data.get("locations", []):
                    pid = (loc.get("metadata") or {}).get("placeId")
                    branch = self.cfg["_by_place"].get(pid)
                    if branch is None:
                        branch = self._auto_branch(loc)
                        log(f"GBP: location not in config, auto-added as {branch['id']} ({branch['brand']} {branch['name']}, placeId={pid})")
                    found[f"{acct['name']}/{loc['name']}"] = branch
                token = data.get("nextPageToken")
                if not token:
                    break
        return found

    def fetch(self, since):
        out = []
        for path, branch in self._locations().items():
            token = None
            while True:
                data = self._get(f"https://mybusiness.googleapis.com/v4/{path}/reviews",
                                 {"pageSize": 50, "orderBy": "updateTime desc", "pageToken": token})
                stop = False
                for rv in data.get("reviews", []):
                    upd = parse_iso(rv.get("updateTime"))
                    if upd and upd < since:
                        stop = True
                        break
                    out.append(_normalize(
                        branch, source=self.name, rid=rv["reviewId"],
                        stars=STAR_WORDS.get(rv.get("starRating")),
                        text=rv.get("comment"),
                        published=rv.get("createTime"),
                        reply=(rv.get("reviewReply") or {}).get("comment"),
                    ))
                token = data.get("nextPageToken")
                if stop or not token:
                    break
        log(f"GBP returned {len(out)} reviews")
        return out


def get_source(cfg):
    return {"apify": ApifySource, "gbp": GBPSource}[cfg.get("source", "apify")](cfg)
